package com.lion.database_project.adapter

interface OnClickConvertListener {
    fun onClickItem(shopIdx:Int)
}